#!/usr/bin/env python3
# Amethyst Linux — minimal reimplementation of the GNOME Settings Daemon
# power plugin's brightness interfaces, for systems where the upstream
# power plugin cannot run (it depends on libgnome-desktop's gnome-rr APIs,
# which were removed from modern releases).
#
# It claims org.gnome.SettingsDaemon.Power on the session bus and exports
# /org/gnome/SettingsDaemon/Power with the Screen + Keyboard interfaces
# that gsd-media-keys talks to.
import shutil
import subprocess
import sys

import gi

gi.require_version("Gio", "2.0")
gi.require_version("GLib", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

BUS_NAME = "org.gnome.SettingsDaemon.Power"
OBJ_PATH = "/org/gnome/SettingsDaemon/Power"

NODE_XML = """
<node>
  <interface name='org.gnome.SettingsDaemon.Power'>
    <property name='LidIsClosed' type='b' access='read'/>
    <property name='LidIsPresent' type='b' access='read'/>
    <property name='OnBattery' type='b' access='read'/>
    <property name='Percentage' type='d' access='read'/>
    <property name='ActiveDevice' type='s' access='read'/>
  </interface>
  <interface name='org.gnome.SettingsDaemon.Power.Screen'>
    <method name='StepUp'/>
    <method name='StepDown'/>
    <method name='Toggle'/>
    <method name='Cycle'/>
  </interface>
  <interface name='org.gnome.SettingsDaemon.Power.Keyboard'>
    <method name='StepUp'/>
    <method name='StepDown'/>
    <method name='Toggle'/>
    <method name='Cycle'/>
  </interface>
</node>
"""

STEP = "5%"


def backlight_set(delta):
    if shutil.which("brightnessctl") is None:
        return False
    subprocess.run(["brightnessctl", "-q", "set", delta],
                   check=False,
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
    return True


class PowerImpl:
    def __init__(self):
        self._node = Gio.DBusNodeInfo.new_for_xml(NODE_XML)
        self._on_battery = True

    def _iface(self, name):
        for i in self._node.interfaces:
            if i.name == name:
                return i
        return None

    def export(self, connection):
        for iface_name in (
            "org.gnome.SettingsDaemon.Power",
            "org.gnome.SettingsDaemon.Power.Screen",
            "org.gnome.SettingsDaemon.Power.Keyboard",
        ):
            iface = self._iface(iface_name)
            if iface is None:
                continue
            connection.register_object(
                OBJ_PATH,
                iface,
                self._handle_method_call,
                self._handle_get_property,
                None)

    def _handle_get_property(self, connection, sender, object_path,
                             interface_name, property_name, likewise_error):
        if property_name in ("LidIsClosed", "LidIsPresent"):
            return GLib.Variant("b", False)
        if property_name == "OnBattery":
            return GLib.Variant("b", self._on_battery)
        if property_name == "Percentage":
            return GLib.Variant("d", 1.0)
        if property_name == "ActiveDevice":
            return GLib.Variant("s", "")
        return None

    def _handle_method_call(self, connection, sender, object_path,
                            interface_name, method_name, parameters,
                            invocation):
        if method_name in ("StepUp", "Toggle"):
            backlight_set("+" + STEP)
        elif method_name in ("StepDown",):
            backlight_set("-" + STEP)
        elif method_name == "Cycle":
            pass
        if invocation is not None:
            invocation.return_value(GLib.Variant("()", ()))


def main():
    if shutil.which("brightnessctl") is None:
        print("amethyst-power-screen: brightnessctl not found; exiting",
              file=sys.stderr)
        sys.exit(1)

    loop = GLib.MainLoop()

    def on_bus_acquired(connection, name):
        PowerImpl().export(connection)

    def on_name_acquired(connection, name):
        pass

    def on_name_lost(connection, name):
        print("amethyst-power-screen: lost the well-known name " + name,
              file=sys.stderr)
        loop.quit()

    Gio.bus_own_name(
        Gio.BusType.SESSION,
        BUS_NAME,
        Gio.BusNameOwnerFlags.NONE,
        on_bus_acquired,
        on_name_acquired,
        on_name_lost)

    try:
        loop.run()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
