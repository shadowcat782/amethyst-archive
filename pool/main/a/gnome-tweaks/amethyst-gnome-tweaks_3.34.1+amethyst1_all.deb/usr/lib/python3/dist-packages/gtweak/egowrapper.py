# Copyright (c) 2011 John Stowers
# SPDX-License-Identifier: GPL-3.0+
# License-Filename: LICENSES/GPL-3.0

import json
import logging

import gi
gi.require_version("Soup", "3.0")
from gi.repository import GLib, GObject, Soup
from gi.repository import Soup


class ExtensionsDotGnomeDotOrg(GObject.GObject):

    __gsignals__ = {
      "got-extensions": (GObject.SignalFlags.RUN_FIRST, GObject.TYPE_NONE,
                         (GObject.TYPE_PYOBJECT,)),
      "got-extension-info": (GObject.SignalFlags.RUN_FIRST, GObject.TYPE_NONE,
                             (GObject.TYPE_PYOBJECT, GObject.TYPE_STRING)),
    }

    def __init__(self, shell_version_tuple):
        GObject.GObject.__init__(self)
        self._session = Soup.Session()

        self._shell_version_tuple = shell_version_tuple
        self._extensions = {}

    def _send(self, url, callback, user_data):
        msg = Soup.Message.new('GET', url)
        self._session.send_async(msg, GLib.PRIORITY_DEFAULT, None,
                                 callback, (msg, user_data))

    def _send_finish(self, session, result, user_data):
        msg, tag = user_data
        if msg is None:
            return None, None
        try:
            body = session.send_and_read_finish(result)
        except GLib.Error as e:
            logging.debug("extensions.gnome.org request failed: %s", e)
            return None, None
        if msg.get_status() != Soup.StatusCode.OK:
            logging.debug("extensions.gnome.org HTTP %s", msg.get_status())
            return None, None
        data = body.get_data() if body is not None else None
        if not data:
            return None, None
        try:
            resp = json.loads(data)
        except Exception:
            logging.exception("Failed to parse extensions.gnome.org reply")
            return None, None
        return resp, tag

    def _query_extensions_finished(self, session, result, user_data):
        resp, tag = self._send_finish(session, result, user_data)
        if resp is None:
            return
        # server returns a list of extensions which may contain duplicates, dont know
        for e in resp.get("extensions", []):
            self._extensions[e["uuid"]] = e
        self.emit("got-extensions", self._extensions)

    def _query_extension_info_finished(self, session, result, user_data):
        resp, uuid = self._send_finish(session, result, user_data)
        if resp is None:
            return
        self.emit("got-extension-info", resp, uuid)

    def query_extensions(self):
        url = "https://extensions.gnome.org/extension-query/?"

        ver = self._shell_version_tuple
        if ver[1] % 2:
            # if this is a development version (odd) then query the full version
            url += "shell_version=%d.%d.%d&" % ver
        else:
            # else query in point releases up to the current version
            # and filter duplicates from the reply
            url += "shell_version=%d.%d&" % (ver[0], ver[1])
            for i in range(1, ver[2]+1):
                url += "shell_version=%d.%d.%d&" % (ver[0], ver[1], i)
        # non-paginated
        url += "n_per_page=-1"

        logging.debug("Query URL: %s" % url)
        self._send(url, self._query_extensions_finished, None)

    def query_extension_info(self, extension_uuid):
        if extension_uuid in self._extensions:
            self.emit("got-extension-info", self._extensions[extension_uuid])
            return

        url = "https://extensions.gnome.org/extension-info/?uuid=%s" % extension_uuid
        logging.debug("Query URL: %s" % url)
        self._send(url, self._query_extension_info_finished, extension_uuid)

    def get_download_url(self, extinfo):
        url = "https://extensions.gnome.org/download-extension/%s.shell-extension.zip?version_tag=%d"
        # version tag is the pk in the shell_version_map
        # url = url % (extinfo["uuid"],


if __name__ == "__main__":
    import pprint
    from gi.repository import Gtk

    def _got_ext(ego, extensions):
        print("="*80)
        pprint.pprint(list(extensions.values()))

    def _got_ext_info(ego, extension):
        pprint.pprint(extension)

    logging.basicConfig(format="%(levelname)-8s: %(message)s", level=logging.DEBUG)

    e = ExtensionsDotGnomeDotOrg((3, 4, 1))

    e.connect("got-extensions", _got_ext)
    e.connect("got-extension-info", _got_ext_info)

    e.query_extensions()
    # e.query_extensions((3, 4, 0))
    # e.query_extensions((3, 3, 2))
    e.query_extension_info("user-theme@gnome-shell-extensions.gcampax.github.com")

    Gtk.main()
