#!/bin/sh
exec >/dev/console 2>&1
echo "VERIFY-AUTO: begin"
if ! grep -qs 'amethyst.verify=1' /proc/cmdline; then
  echo "VERIFY-AUTO: no amethyst.verify flag, skipping"
  exit 0
fi
mkfs.ext4 -F /dev/vda >/dev/null 2>&1
mkdir -p /mnt/verify-target
mount /dev/vda /mnt/verify-target || echo "VERIFY-AUTO: mount target FAILED"
python3 /usr/lib/amethyst/verify-unpackfs.py
echo "VERIFY-AUTO: verify rc=$?"
echo "VERIFY-AUTO: powering off"
sync
poweroff -f
