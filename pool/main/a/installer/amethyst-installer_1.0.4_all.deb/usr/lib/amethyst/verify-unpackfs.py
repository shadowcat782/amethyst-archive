import sys, os, subprocess, shutil, traceback
sys.path.insert(0, "/usr/lib/x86_64-linux-gnu/calamares")
import libcalamares
from libcalamares import GlobalStorage

TARGET = "/mnt/verify-target"
CONF = "/etc/calamares/modules/unpackfs.conf"
SRC = "/run/live/medium/live/filesystem.squashfs"

def sh(cmd, **kw):
    print("VERIFY-SH:", " ".join(cmd), flush=True)
    return subprocess.run(cmd, **kw)

print("VERIFY: starting calamares unpackfs job test", flush=True)
print("VERIFY: python", sys.version.split()[0], flush=True)

conf_text = open(CONF).read()
print("VERIFY: shipped unpackfs.conf:\n" + conf_text, flush=True)
assert SRC in conf_text, "unpackfs.conf does not contain the fixed source path"
print("VERIFY: shipped conf contains fixed source", flush=True)

print("VERIFY: listing medium live dir:", flush=True)
sh(["ls", "-la", "/run/live/medium/live/"])
print("VERIFY: listing rootfs mountpoints:", flush=True)
sh(["ls", "-la", "/run/live/rootfs/"])

gs = GlobalStorage(None)
gs.insert("rootMountPoint", TARGET)
libcalamares.globalstorage = gs

class FakeJob:
    module_name = "unpackfs"
    pretty_name = "unpackfs"
    configuration = {"unpack": [{"source": SRC, "sourcefs": "squashfs", "destination": ""}]}
    working_path = "/tmp"
    progress = []
    @staticmethod
    def setprogress(p):
        FakeJob.progress.append(p)

libcalamares.job = FakeJob()

import importlib.util

def run_unpack():
    spec = importlib.util.spec_from_file_location(
        "verify_unpackfs", "/usr/lib/x86_64-linux-gnu/calamares/modules/unpackfs/main.py")
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
        result = mod.run()
        print("VERIFY: run() returned:", repr(result), flush=True)
        return result
    except Exception:
        print("VERIFY: EXCEPTION RAISED:", flush=True)
        traceback.print_exc()
        return ("exception", None)

print("VERIFY: running unpackfs job (wipes target)...", flush=True)
for entry in os.listdir(TARGET):
    p = os.path.join(TARGET, entry)
    if os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True)
    else:
        os.remove(p)
result = run_unpack()

nfiles = subprocess.run(["find", TARGET, "-type", "f"], capture_output=True, text=True).stdout.count("\n")
print("VERIFY: files extracted to target:", nfiles, flush=True)
print("VERIFY: progress calls:", len(FakeJob.progress), flush=True)
print("VERIFY: RESULT =", repr(result), flush=True)
print("VERIFY-DONE", flush=True)
