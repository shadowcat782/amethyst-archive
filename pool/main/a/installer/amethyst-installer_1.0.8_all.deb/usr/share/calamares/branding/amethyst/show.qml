/* === Amethyst Linux Calamares slideshow ===
 *
 * Shown while the installer unpacks the live squashfs onto the target
 * drive. Keep it light: one image and short lines, no network access.
 */

import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation

    function nextSlide() {
        presentation.goToNextSlide();
    }

    Timer {
        id: advanceTimer
        interval: 2500
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: nextSlide()
    }

    Slide {
        Image {
            id: background
            source: "logo.png"
            width: 160; height: 160
            fillMode: Image.PreserveAspectFit
            anchors.centerIn: parent
        }
        Text {
            anchors.horizontalCenter: background.horizontalCenter
            anchors.top: background.bottom
            anchors.topMargin: 24
            text: "<b>Welcome to Amethyst Linux</b><br/>" +
                  "Sit back while your desktop is set up."
            textFormat: Text.RichText
            color: "#ffffff"
            wrapMode: Text.WordWrap
            width: presentation.width * 0.8
            horizontalAlignment: Text.Center
            font.pixelSize: 16
        }
    }

    Slide {
        centeredText: "<b>GNOME 3 Revitalized</b><br/>" +
                      "The classic GNOME 3 design,<br/>" +
                      "forward-ported to today&#39;s libraries."
        textFormat: Text.RichText
    }

    Slide {
        centeredText: "<b>Made for the desktop</b><br/>" +
                      "Gaming first: Steam, Proton, Lutris<br/>" +
                      "and everything you need — preinstalled,<br/>" +
                      "removable, never mandatory."
        textFormat: Text.RichText
    }

    Slide {
        centeredText: "<b>Rollin&#39; with Debian testing</b><br/>" +
                      "Fresh, tested packages, all the time."
        textFormat: Text.RichText
    }

    Slide {
        centeredText: "<b>Almost there…</b><br/>" +
                      "Your Amethyst is nearly ready."
        textFormat: Text.RichText
    }
}
